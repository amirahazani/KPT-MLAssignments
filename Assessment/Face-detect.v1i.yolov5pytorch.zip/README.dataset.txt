# Face-detect > 2022-08-01 3:09pm
https://universe.roboflow.com/object-detection/face-detect-aqtre

Provided by Roboflow
License: CC BY 4.0

